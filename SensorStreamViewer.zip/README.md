
# Summary

The SensorStreamViewer project provides a simple tool to view all the HoloLens Research Mode streams through a UWP application. This project also demostrates a way to access the streams without using the HoloLensForCV Library and directly uses the Media Foundation APIs. 

This sample has been derived from the CameraFrames sample of Windows 10.


