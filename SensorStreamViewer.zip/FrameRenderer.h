//*********************************************************
//
// Copyright (c) Microsoft. All rights reserved.
// This code is licensed under the Microsoft Public License.
// THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
// IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
// PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
//
//*********************************************************

#pragma once

#include "LookupTable.h"
#include <inspectable.h>

namespace SensorStreaming
{	
	// {5DCC7829-9471-4D78-8C27-5B2B9A0EC5EF}
	// Type : IUnknown (SensorStreaming::ICameraIntrinsics)
	// Stores intrinsics of the captured frame
	EXTERN_GUID(MFSampleExtension_SensorStreaming_CameraIntrinsics, 0x5dcc7829, 0x9471, 0x4d78, 0x8c, 0x27, 0x5b, 0x2b, 0x9a, 0xe, 0xc5, 0xef);

	struct
		__declspec(uuid("9086e81c-0485-434d-918b-25924a877b09"))
		ICameraIntrinsics : IInspectable
	{
		virtual HRESULT __stdcall MapImagePointToCameraUnitPlane(_In_ float(&uv)[2],
			_Out_ float(&xy)[2]) = 0;

		virtual HRESULT __stdcall MapCameraSpaceToImagePoint(_In_ float(&xy)[2],
			_Out_ float(&uv)[2]) = 0;
	};

    // Function type used to map a scanline of pixels to an alternate pixel format.
    typedef std::function<void(int, byte*, byte*)> TransformScanline;

    public ref class FrameRenderer sealed
    {
    public:
        FrameRenderer(Windows::UI::Xaml::Controls::Image^ image);

    public: // Public methods.
        void SetSensorName(Platform::String^ sensorName);

        /// <summary>
        /// Buffer and render frames.
        /// </summary>
        void ProcessFrame(Windows::Media::Capture::Frames::MediaFrameReference^ frame);

        /// <summary>
        /// Determines the subtype to request from the MediaFrameReader that will result in
        /// a frame that can be rendered by ConvertToDisplayableImage.
        /// </summary>
        /// <returns>Subtype string to request, or null if subtype is not renderable.</returns>
        static Platform::String^ GetSubtypeForFrameReader(
            Windows::Media::Capture::Frames::MediaFrameSourceKind kind,
            Windows::Media::Capture::Frames::MediaFrameFormat^ format);

    private: // Private static methods.
        /// <summary>
        /// Transforms pixels of inputBitmap to an output bitmap using the supplied pixel transformation method.
        /// Returns nullptr if translation fails.
        /// </summary>
        static Windows::Graphics::Imaging::SoftwareBitmap^ TransformBitmap(
            Windows::Graphics::Imaging::SoftwareBitmap^ inputBitmap,
            TransformScanline pixelTransformation);

        static Windows::Graphics::Imaging::SoftwareBitmap^ TransformVlcBitmap(
            Windows::Graphics::Imaging::SoftwareBitmap^ inputBitmap);

        static Windows::Graphics::Imaging::SoftwareBitmap^ DeepCopyBitmap(
            Windows::Graphics::Imaging::SoftwareBitmap^ inputBitmap);

    private: // Private instance methods.
        /// <summary>
        /// Converts the input frame to BGRA8 premultiplied alpha format and returns the result.
        /// Returns nullptr if the input frame cannot be converted BGRA8 premultiplied alpha.
        /// </summary>
        Windows::Graphics::Imaging::SoftwareBitmap^ ConvertToDisplayableImage(
            Windows::Media::Capture::Frames::VideoMediaFrame^ inputFrame);

    private: // Private data.
        Windows::UI::Xaml::Controls::Image^ m_imageElement;
        Platform::String^ m_sensorName;

        static const int32_t c_maxNumberOfTasksScheduled{ 1 };
        static const int32_t c_maxNumberOfTasksRunning{ 1 };

        volatile long m_numberOfTasksScheduled{ 0 };
        volatile long m_numberOfTasksRunning{ 0 };
    };
}